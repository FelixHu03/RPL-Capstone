<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$host = "localhost"; $user = "root"; $pass = ""; $db   = "washngo_db";
$koneksi = mysqli_connect($host, $user, $pass, $db);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // 1. Cek apakah email sudah terdaftar
    $checkQuery = "SELECT * FROM users WHERE email = '$email'";
    $checkResult = mysqli_query($koneksi, $checkQuery);

    if (mysqli_num_rows($checkResult) > 0) {
        echo json_encode(['value' => 0, 'message' => 'Email sudah digunakan!']);
    } else {
        // 2. Enkripsi Password (Hashing) agar aman
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // 3. Simpan ke Database
        $insertQuery = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$hashed_password')";
        
        if (mysqli_query($koneksi, $insertQuery)) {
            echo json_encode(['value' => 1, 'message' => 'Registrasi Berhasil']);
        } else {
            echo json_encode(['value' => 0, 'message' => 'Gagal Mendaftar']);
        }
    }
}
?>