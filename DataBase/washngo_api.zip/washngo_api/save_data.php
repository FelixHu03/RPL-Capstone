<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$host = "localhost"; $user = "root"; $pass = ""; $db = "washngo_db";
$koneksi = mysqli_connect($host, $user, $pass, $db);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari Flutter
    $email = $_POST['email']; // Kita pakai email untuk mencari user_id
    $no_hp = $_POST['no_hp'];
    $alamat = $_POST['alamat'];
    $tgl_lahir = $_POST['tanggal_lahir']; // Format YYYY-MM-DD
    $merk = $_POST['merk'];
    $plat = $_POST['plat'];

    // 1. Cari user_id berdasarkan email
    $cekUser = mysqli_query($koneksi, "SELECT id FROM users WHERE email = '$email'");
    $userData = mysqli_fetch_assoc($cekUser);
    
    if ($userData) {
        $user_id = $userData['id'];

        // 2. Simpan ke user_profiles
        $queryProfile = "INSERT INTO user_profiles (user_id, no_hp, alamat, tanggal_lahir) 
                         VALUES ('$user_id', '$no_hp', '$alamat', '$tgl_lahir')";
        
        // 3. Simpan ke user_vehicles
        $queryVehicle = "INSERT INTO user_vehicles (user_id, merk_kendaraan, plat_kendaraan) 
                         VALUES ('$user_id', '$merk', '$plat')";

        // Jalankan kedua query
        if (mysqli_query($koneksi, $queryProfile) && mysqli_query($koneksi, $queryVehicle)) {
            echo json_encode(['value' => 1, 'message' => 'Data Berhasil Disimpan']);
        } else {
            echo json_encode(['value' => 0, 'message' => 'Gagal Menyimpan Data']);
        }
    } else {
        echo json_encode(['value' => 0, 'message' => 'User tidak ditemukan']);
    }
}
?>