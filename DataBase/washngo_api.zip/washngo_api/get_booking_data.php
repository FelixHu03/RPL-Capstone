<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
include 'koneksi.php'; // Pastikan file koneksi database sudah ada

$email = $_POST['email'];

// 1. Ambil Nama User
$queryUser = mysqli_query($koneksi, "SELECT id, name FROM users WHERE email = '$email'");
$user = mysqli_fetch_assoc($queryUser);

if ($user) {
    $user_id = $user['id'];

    // 2. Ambil Daftar Mobil User
    $queryMobil = mysqli_query($koneksi, "SELECT * FROM user_vehicles WHERE user_id = '$user_id'");
    $mobilList = array();
    while ($row = mysqli_fetch_assoc($queryMobil)) {
        // Format: "BG 1234 XY (Toyota Avanza)"
        $mobilList[] = $row['plat_kendaraan'] . " (" . $row['merk_kendaraan'] . ")";
    }

    echo json_encode([
        'value' => 1,
        'nama' => $user['name'],
        'vehicles' => $mobilList
    ]);
} else {
    echo json_encode(['value' => 0, 'message' => 'User not found']);
}
