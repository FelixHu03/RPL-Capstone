<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
include 'koneksi.php';

$email = $_POST['email'];
$service = $_POST['service'];
$vehicle = $_POST['vehicle'];
$schedule = $_POST['schedule'];
$date = $_POST['date']; // Format YYYY-MM-DD
$bay = $_POST['bay'];
$price = $_POST['price'];

// Cari user_id dulu
$cekUser = mysqli_query($koneksi, "SELECT id, name FROM users WHERE email = '$email'");
$userData = mysqli_fetch_assoc($cekUser);

if ($userData) {
    $user_id = $userData['id'];
    $nama_pelanggan = $userData['name'];

    // Cek apakah bilik sudah dipesan orang lain di jam & tanggal yang sama
    $cekJadwal = mysqli_query($koneksi, "SELECT id FROM bookings WHERE booking_date='$date' AND schedule_time='$schedule' AND bay_number='$bay'");

    if (mysqli_num_rows($cekJadwal) > 0) {
        echo json_encode(['value' => 0, 'message' => 'Maaf, Bilik ini sudah dipesan di jam tersebut!']);
    } else {
        // Simpan Booking
        $query = "INSERT INTO bookings (user_id, nama_pelanggan, service_name, vehicle_name, schedule_time, booking_date, bay_number, total_price) 
                  VALUES ('$user_id', '$nama_pelanggan', '$service', '$vehicle', '$schedule', '$date', '$bay', '$price')";

        if (mysqli_query($koneksi, $query)) {
            echo json_encode(['value' => 1, 'message' => 'Booking Berhasil!']);
        } else {
            echo json_encode(['value' => 0, 'message' => 'Gagal Booking']);
        }
    }
} else {
    echo json_encode(['value' => 0, 'message' => 'User tidak valid']);
}
