<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
include 'koneksi.php';

$date = $_POST['date'];      // Format: YYYY-MM-DD
$schedule = $_POST['schedule']; // Contoh: "09:00 - 10:30"

// Query: Cari nomor bilik yang SUDAH dipesan pada tanggal & jam tersebut
$query = "SELECT bay_number FROM bookings WHERE booking_date = '$date' AND schedule_time = '$schedule'";
$result = mysqli_query($koneksi, $query);

$booked_bays = array();

while($row = mysqli_fetch_assoc($result)) {
    // Kita simpan nomor biliknya saja ke dalam array (Contoh: [1, 3])
    // Pastikan dikonversi ke integer (angka)
    $booked_bays[] = (int)$row['bay_number'];
}

echo json_encode([
    'value' => 1,
    'booked_bays' => $booked_bays
]);
?>