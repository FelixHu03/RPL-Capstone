<?php
// ==========================================
// FILE: get_user_history.php
// ==========================================

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include 'koneksi.php';

// Terima email dari Flutter
$email = $_POST['email'];

// 1. Cari ID User berdasarkan Email
$cekUser = mysqli_query($koneksi, "SELECT id FROM users WHERE email = '$email'");
$userRow = mysqli_fetch_assoc($cekUser);

if ($userRow) {
    $user_id = $userRow['id'];

    // 2. Ambil Riwayat HANYA milik user tersebut
    // Kita gunakan SELECT * agar nama kolom tetap asli (booking_date, vehicle_name, dll)
    // Sesuai dengan kode Flutter Anda: item['booking_date']
    $query = "SELECT * FROM bookings WHERE user_id = '$user_id' ORDER BY id DESC";
    $result = mysqli_query($koneksi, $query);

    $historyData = array();
    while($row = mysqli_fetch_assoc($result)) {
        $historyData[] = $row;
    }

    // 3. Kirim Format JSON sesuai permintaan Flutter (value & data)
    echo json_encode([
        'value' => 1,
        'message' => 'Data ditemukan',
        'data' => $historyData
    ]);

} else {
    // Jika user tidak ditemukan
    echo json_encode([
        'value' => 0,
        'message' => 'User tidak ditemukan',
        'data' => []
    ]);
}

mysqli_close($koneksi);
?>