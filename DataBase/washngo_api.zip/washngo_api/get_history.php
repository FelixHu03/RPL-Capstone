<?php
// ==========================================
// FILE: get_history.php
// FUNGSI: Mengambil data riwayat dari tabel BOOKINGS
// ==========================================

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// Panggil file koneksi yang sudah Anda rename jadi benar
include 'koneksi.php'; 

// Cek koneksi
if (!$koneksi) {
    echo json_encode([
        "message" => "Koneksi Database Gagal",
        "error" => mysqli_connect_error()
    ]);
    exit;
}

// --- PERBAIKAN QUERY ---

$query = "SELECT 
            id,
            booking_date as tanggal,
            bay_number as bilik,
            vehicle_name as plat,
            schedule_time as jam,
            service_name,
            total_price,
            status
          FROM bookings 
          ORDER BY id DESC";

$result = mysqli_query($koneksi, $query);

$response = array();

if ($result) {
    while($row = mysqli_fetch_assoc($result)) {
        $response[] = $row;
    }
}

echo json_encode($response);

mysqli_close($koneksi);
?>