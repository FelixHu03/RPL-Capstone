<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$host = "localhost"; $user = "root"; $pass = ""; $db   = "washngo_db";
$koneksi = mysqli_connect($host, $user, $pass, $db);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // 1. Cari user berdasarkan email
    $query = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($koneksi, $query);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $hashed_password_from_db = $row['password'];

        // 2. Verifikasi Password
        if (password_verify($password, $hashed_password_from_db)) {
            // Berhasil Login
            echo json_encode([
                'value' => 1, 
                'message' => 'Login Berhasil',
                'name' => $row['name'], // Kirim nama user untuk ditampilkan di Profil nanti
                'email' => $row['email']
            ]);
        } else {
            echo json_encode(['value' => 0, 'message' => 'Password Salah']);
        }
    } else {
        echo json_encode(['value' => 0, 'message' => 'Email tidak ditemukan']);
    }
}
?>