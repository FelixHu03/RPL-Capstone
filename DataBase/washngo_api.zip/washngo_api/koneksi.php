<?php
// File: koneksi.php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "washngo_db"; // Pastikan nama database sama dengan yang Anda buat

$koneksi = mysqli_connect($host, $user, $pass, $db);

if (!$koneksi) {
    die("Koneksi Gagal: " . mysqli_connect_error());
}
?>