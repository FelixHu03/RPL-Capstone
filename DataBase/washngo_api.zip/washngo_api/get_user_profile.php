<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
include 'koneksi.php';

$email = $_POST['email'];

// 1. Ambil Data Diri (Gabungan tabel users & user_profiles)
// Menggunakan LEFT JOIN agar jika user belum isi data diri, nama & email tetap muncul
$queryUser = "SELECT u.id, u.name, u.email, p.no_hp, p.alamat, p.tanggal_lahir 
              FROM users u 
              LEFT JOIN user_profiles p ON u.id = p.user_id 
              WHERE u.email = '$email'";
$resultUser = mysqli_query($koneksi, $queryUser);
$userData = mysqli_fetch_assoc($resultUser);

if ($userData) {
    $user_id = $userData['id'];

    // 2. Ambil Daftar Kendaraan
    $queryMobil = "SELECT * FROM user_vehicles WHERE user_id = '$user_id'";
    $resultMobil = mysqli_query($koneksi, $queryMobil);
    
    $vehicles = array();
    while($row = mysqli_fetch_assoc($resultMobil)) {
        // Format tampilan: "BG 1234 XY (Toyota Avanza)"
        $vehicles[] = $row['plat_kendaraan'] . " (" . $row['merk_kendaraan'] . ")";
    }

    echo json_encode([
        'value' => 1,
        'data' => [
            'name' => $userData['name'],
            'email' => $userData['email'],
            // Gunakan strip (-) jika data belum diisi
            'phone' => $userData['no_hp'] ?? '-', 
            'address' => $userData['alamat'] ?? '-',
            'dob' => $userData['tanggal_lahir'] ?? '-',
            'vehicles' => $vehicles
        ]
    ]);
} else {
    echo json_encode(['value' => 0, 'message' => 'User not found']);
}
?>